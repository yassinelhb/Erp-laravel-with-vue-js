<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Prixvente extends Model
{
    protected $table = 'article_saison';
}
